# tv-ip-checker-auto
电视盒子数据源批量检测工具


## 使用步骤
1. 在`links.txt`里面写入你的数据源，一个占据一行
2. 运行`run_ping.bat`，等待检测完，可用的数据源将写到`reachable_links.txt`里面
